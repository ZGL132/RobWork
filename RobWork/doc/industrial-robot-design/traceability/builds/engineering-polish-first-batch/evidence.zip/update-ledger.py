from pathlib import Path
root=Path(r'C:/Users/zgl18/.codex/worktrees/qp00-gate-repair/RobWork')
p=root/'RobWork/docs/superpowers/plans/2026-10-15-engineering-polish-work-packages.md'
s=p.read_text(encoding='utf-8-sig')
s=s.replace('日期：2026-10-15；版本：1.0；','日期：2026-10-15；版本：1.1；',1)
s=s.replace('**QP-00.01 冻结复现场景**','**QP-00.01 冻结复现场景**',1)
s=s.replace('- [ ] **QP-00.01','- [x] **QP-00.01',1)
s=s.replace('| QP-00 | 基线、历史账目与修复登记 | WP-A/B；B0 | 无 | 无 | 核查中，仅入口检查完成 |','| QP-00 | 基线、历史账目与修复登记 | WP-A/B；B0 | 无 | 无 | 首批已执行；门禁修复待独立验收，详见文末 |')
s=s.replace('| QP-01 | 六轴参考工程与场景数据 | WP-E/B；B0/B1 | 可与 QP-00 盘点交错 | QP-00 基线记录、QP-02 输入核验 | 未启动 |','| QP-01 | 六轴参考工程与场景数据 | WP-E/B；B0/B1 | 可与 QP-00 盘点交错 | QP-00 基线记录、QP-02 输入核验 | 合成输入/参考和真导入草稿重开；正式工程未冻结 |')
s=s.replace('| QP-02 | 单位、物性、建模和编译真值 | WP-C/E/B；B1 | QP-00 基线记录 | QP-01 场景输入可用 | 未启动 |','| QP-02 | 单位、物性、建模和编译真值 | WP-C/E/B；B1 | QP-00 基线记录 | QP-01 场景输入可用 | 部分核查；F-784 真库复现/RT-T16 ready |')
s += '''
## 7. 2026-10-15 首批执行更新

历史入口基线 7ce545e3 仍保留；本轮实际冻结基线为 redesign-main@01223053a130c7b437c6a32f439bdd1c58ba8d54。实施分支 wp01-t05，仅两个 CMake 门禁源码改动，未改数值或 UI 源码。

- QP-00.01 已完成：环境、目标、策略后端和基线可复现；QP-00.02 的实际运行见最终矩阵，不能将首次超时/磁盘失败抹去。
- QP-00.03 已列全 22 个开放 blocking/major 索引，优先条目分静态/实测/未执行，F-795 已修但账未翻；502 个开放条目尚未逐项复核，整项未勾完成。
- QP-00.04 已登记 WP-01-T05 与 RT-T16；优化服务/旧冒烟断言/JSON 缺口列为后继范围，尚未完成全部任务编译。
- QP-01.01～04：29 数据集/118 文件完整性通过；形成合成六轴输入、6 FK/9 安装/8 物性独立参考；真实导入＋草稿只读重开通过。真实目录/实测、S1 正式应用编译、S2～S8、基线/方案分支与跨机器移交未齐，原工作项不整项勾选。
- QP-02.01～04：单位与参考系已登记，F-784 双向误判链接真实 runtime 复现；RT-T16 仅 ready，数值修复/9 组产品链对照/正式 S1～S3 未执行。
- QP-07.01、QP-09.01 已做部分只读核查；优化 run 服务缺接线，真实搜索和正式结果资格闭环未完成。其他包状态维持原记录。

[本轮交付与独立验收入口](../../../doc/industrial-robot-design/traceability/engineering-polish/2026-10-15-first-batch-delivery.md)。本轮复选框只对应完整工作项；局部已完成工作以上述证据描述。首批三个包当前不得整体收口，不把“已建立输入草案/已复现缺陷”写成“正式研发流程已通过”。
'''
p.write_text(s,encoding='utf-8')
p=root/'RobWork/doc/industrial-robot-design/development-task-breakdown.md'
s=p.read_text(encoding='utf-8-sig').replace('testkit.md §2.4；WP-23-T02/T03/T06/T07/T08 门禁登记件','testkit.md §2.4；WP-23-T02/T03/T04/T05/T06/T07/T08 门禁登记件')
p.write_text(s,encoding='utf-8')
p=root/'RobWork/doc/industrial-robot-design/units/testkit.md'
s=p.read_text(encoding='utf-8-sig').replace('| 文档版本 | v1.6（','| 文档版本 | v1.7（2026-10-15 WP-01-T05 门禁维护登记，见文末；v1.6＝',1)
p.write_text(s,encoding='utf-8')
