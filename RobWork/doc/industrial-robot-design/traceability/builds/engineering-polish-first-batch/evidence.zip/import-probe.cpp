// QP-01 公开 API 诊断：真实导入映射→草稿编码→创建/保存→只读重开。
// 输入资源快照由本探针装配（摘要计算真实）；不代替 io 向导或完整模型应用。
#include <sdurws/ird/modeling/Import.hpp>
#include <sdurws/ird/modeling/Codec.hpp>
#include <sdurws/ird/modeling/RobotDesign.hpp>
#include <sdurws/ird/project/ProjectStore.hpp>
#include <sdurws/ird/project/DraftService.hpp>
#include <sdurws/ird/project/PersistenceFormat.hpp>
#include <fstream>
#include <iostream>
#include <iterator>
#include <ctime>
#include <iomanip>
#include <sstream>
int main(int argc, char** argv) {
    using namespace sdurws::ird;
    try {
        if (argc != 3) return 2;
        std::ifstream file(argv[1], std::ios::binary);
        if (!file) return 3;
        modeling::ValidatedSource source;
        source.bytes.assign(std::istreambuf_iterator<char>(file), {});
        core::ContentDigester digest;
        digest.update(source.bytes.data(), source.bytes.size());
        source.entrySnapshot.contentDigest = digest.finalize();
        source.entrySnapshot.finalPath = argv[1];
        source.entrySnapshot.sizeBytes = source.bytes.size();
        source.dependencyTree.rootRel = "synthetic-6r.urdf";
        io::ResourceNode node;
        node.relPath = source.dependencyTree.rootRel;
        node.exists = true;
        node.snapshot = source.entrySnapshot;
        source.dependencyTree.nodes.push_back(node);
        std::vector<core::DiagnosticRecord> diags;
        auto imported = modeling::ModelImportMapper{}.mapUrdf(source, {}, diags);
        std::cout << "importDraft=" << imported.draft.has_value()
                  << " errors=" << imported.report.errors.size()
                  << " axes=" << imported.report.chainCapability.movableAxes
                  << " submittable=" << imported.report.submittable << std::endl;
        if (!imported.draft) return 4;
        for (const auto& error : imported.report.errors)
            std::cout << error.kind << " " << error.subject << " " << error.detail << std::endl;
        auto violations = modeling::checkInvariants(*imported.draft);
        std::cout << "invariantViolations=" << violations.size() << std::endl;
        if (!violations.empty() || !imported.report.submittable) return 5;
        const auto encoded = modeling::RobotDesignCodec{}.encode(
            modeling::ObjectVariant{*imported.draft}, modeling::kCurrentFormatVersion);
        const auto& bytes = encoded.get();
        std::string payload;
        const char* digits = "0123456789abcdef";
        for (auto b : bytes) { payload += digits[b >> 4]; payload += digits[b & 15]; }
        auto created = project::ProjectStoreFactory::createNew(argv[2], "QP synthetic six-axis reference draft");
        auto& store = *created.store;
        const auto projectId = store.projectId();
        auto branch = store.query().branchTips().at(0).id;
        project::DraftDocument document;
        document.schemaVersion = project::kSchemaVersionCurrent; // project 持久化版本，与 modeling codec 自有版本无关。
        document.projectId = projectId;
        document.branchId = branch;
        document.moduleId = "modeling";
        document.payload = payload;
        const auto savedTime = std::time(nullptr);
        std::tm savedUtc{};
        gmtime_s(&savedUtc, &savedTime);
        std::ostringstream savedText;
        savedText << std::put_time(&savedUtc, "%Y-%m-%dT%H:%M:%S.000Z");
        document.savedAtUtc = savedText.str(); // 元数据记录实际保存时刻，不影响模型输入身份。
        document.baseRevisionId = store.query().branchTips().at(0).tip;
        const bool saved = store.drafts().save(document).ok;
        std::cout << "draftSaved=" << saved << std::endl;
        if (!saved) return 6;
        created.store.reset();
        project::OpenStoreRequest request;
        request.path = argv[2];
        request.mode = project::OpenMode::ReadOnly;
        auto reopened = project::ProjectStoreFactory::open(request);
        auto restored = reopened.store->drafts().tryLoad(branch, "modeling", diags);
        std::cout << "restored=" << restored.has_value() << " sameProject=" << (reopened.store->projectId() == projectId) << std::endl;
        for (const auto& d : diags) std::cout << "diagnostic=" << d.context << " cause=" << d.cause << std::endl;
        const bool same = restored && restored->payload == payload && reopened.store->projectId() == projectId;
        std::cout << "reopenedReadonly=" << !reopened.writable << " draftByteIdentical=" << same
                  << " payloadBytes=" << payload.size() << std::endl;
        return same && !reopened.writable ? 0 : 7;
    } catch (const std::exception& error) {
        std::cout << "error=" << error.what() << std::endl;
        return 8;
    }
}




