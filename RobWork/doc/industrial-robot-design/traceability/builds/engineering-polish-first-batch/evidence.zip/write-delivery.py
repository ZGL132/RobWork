from pathlib import Path
import json, xml.etree.ElementTree as ET, hashlib, re, shutil
repo=Path(r'D:/10_Source_Repos/21_robot/RobWork')
wt=Path(r'C:/Users/zgl18/.codex/worktrees/qp00-gate-repair/RobWork')
run=repo/'build/engineering-polish/20261015-first-batch'
doc=wt/'RobWork/doc/industrial-robot-design'
out=doc/'traceability/engineering-polish'
out.mkdir(parents=True,exist_ok=True)
base='01223053a130c7b437c6a32f439bdd1c58ba8d54'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def write(name,s): (out/name).write_text(s.strip()+'\n',encoding='utf-8')
def table(headers,rows):
    return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(str(x).replace('|','／').replace('\n',' ') for x in row)+' |\n' for row in rows)
phases={}
for phase in ['integration','integration-perf-retry','smoke']:
    result=run/f'{phase}-results.json'
    rows=read(result) if result.exists() else []
    if isinstance(rows,dict): rows=[rows]
    details=[]
    for row in rows:
        p=run/phase/row['name']/'gtest.xml'
        counts=dict(tests=0,failed=0,skipped=0,disabled=0)
        skipped=[]
        if p.exists():
            root=ET.parse(p).getroot()
            for tc in root.iter('testcase'):
                counts['tests']+=1
                counts['failed']+=int(tc.find('failure') is not None or tc.find('error') is not None)
                counts['disabled']+=int(tc.get('status')=='notrun')
                if tc.find('skipped') is not None:
                    counts['skipped']+=1
                    skipped.append({'case':tc.get('classname','')+'.'+tc.get('name',''),'reason':tc.find('skipped').get('message','')})
        details.append(dict(row,counts=counts,skippedCases=skipped,nativeJson=(run/phase/row['name']/'ird-test-report.json').exists()))
    phases[phase]=details
(out/'test-results-summary.json').write_text(json.dumps(phases,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
allrows=[]
for phase,rows in phases.items():
    for r in rows:
        c=r['counts']; allrows.append([phase,r['name'],r['exit'],c['tests'],c['failed'],c['skipped'],c['disabled'],'有' if r['nativeJson'] else '缺'])
write('test-target-matrix.md','# 首批实际执行目标矩阵\n\n每行退出码来自本轮原始结果；用例计数来自 gtest XML。ctest PASS 不隐藏内部 SKIP/disabled；缺 XML 不推算用例数。性能 retry 单列，不抹去首次超时。\n\n'+table(['模式','目标','exit','XML用例','失败','跳过','未运行','原生JSON'],allrows))
meta=read(run/'environment.json')
write('qp-00-baseline.md',f'''
# QP-00 首批基线与门禁修复证据

日期：2026-10-15；基线 `{base}`（redesign-main）。实施分支 `wp01-t05`，基于同一 SHA；冻结 main 零改动。此文是实施自测记录，独立验收未执行。

## 环境和覆盖边界

Windows 11 10.0.26200，MSVC 2022 x64，CMake 4.3.1，Qt 6.11.1 msvc2022_64，Python DLL/运行库位于 D:/software/Miniconda3，vcpkg 经典 x64-windows。CPU i9-13950HX、32 逻辑处理器。集成缓存 `RWS_BUILD_INDUSTRIALROBOT=ON`；原始环境、缓存和目标清单在证据包内。

碰撞策略当前注册的是 policy `currentRegisteredBackend()` 返回的 frozen builtin descriptor；不能将 CMake 同时发现的 PQP/Bullet 当作本案例已用后端。初始环境记录含一个 ctest 进程，占用事实保留，不宣称严格专机性能基准。

双模式所指为 industrialrobot 全部 45 个登记测试目标；集成另构建正式宿主 `sdurws_ird_studio`。没有执行框架所有示例/插件的无目标全构建，F-714 的框架目标风险仍在未审范围。

## 本轮执行结果

- 集成：45 测试目标＋正式宿主构建 exit=0。首次 44 个 ctest PASS；optimization_perf 被本轮编排设置的 120 秒上限截断，原日志保留。600 秒重跑 exit=0（213.79 秒）；最终 45/45 目标取得 PASS，不覆盖首轮失败。
- 独立：第一次 configure=0，构建因 D 盘耗尽而 exit=1（MSB4018 System.IO.IOException），未运行其后测试。该树已移至 C 盘保存；重跑使用 C 盘独立目录，完整构建 exit=0、45/45 目标 PASS，详见最终目标矩阵。不得将旧 exe 当新构建结果。
- 旧基线门禁：22 个真实命中；独立基线虽未跑完构建，门禁分类错误已有直接扫描实证。
- 修复分支：集成与独立配置均 exit=0，两个模式 `ird_gates` 均 exit=0；17 个扫描器自测全符合预期（6 个合法夹具、11 个应拒夹具）。旧分类在新增合法夹具上必红，修复后转绿。

集成最终 XML 共 4737 用例条目、0 失败、6 SKIP；独立 4255 条、0 失败、5 SKIP。两模式最终各 8 个目标缺原生 JSON（首次集成另含超时未产生的性能报告）。其中 5 个 GUI SKIP 均保持未执行，runtime 的额外 SKIP 为父用例派生执行的子进程入口。

两模式用例数不同源于 CMake 的框架条件源与 core 预处理分支；独立模式不覆盖真实 WorkCell 编译/碰撞/轨迹等集成用例。已从实际 vcxproj 导出 [编译源差异](mode-source-differences.json)，原有 CMake 和条件代码未修改。集成才是唯一交付口径，独立通过不能替代集成。

[逐目标与原生 JSON 缺口](test-target-matrix.md)；[机器可读用例/跳过详情](test-results-summary.json)。本轮部分旧测试没有原生 JSON 监听器，缺项如实列明；汇总 JSON 是派生文件，不冒充 `ird-test-report.json`。stdout 部分中文经 MSBuild 管道存在编码显示问题，另保留直接 CMake UTF-8 诊断；不声称所有日志均无乱码。

## 门禁改动与防退化

契约 [WP-01-T05](../../tasks/foundation/WP-01-T05.json)。仅修改两个 CMake 门禁文件：精确识别 perf_test/largedata_perf_test；仅为已登记的 7 条性能测试跨域边补白名单；openbench_worker 按精确工具边链 project，不获得测试身份。未放开业务库互链、testkit 或 Qt 红线。

新增正反例使用真实扫描器：合法性能目标、登记跨域、合法 worker；未登记跨域仍 SUB、worker 链 testkit 仍 T1、perf_test_extra 仍 T1。已有 L2 链 Qt/R1/R2 等自测保留。红证据 gate-red.log、绿证据 gate-green.log 和两模式 gate-wt-*.log 均入证据包。

基线 C++ 双模式构建/测试在主仓原源码上运行；分支独立重新配置并运行变动的门禁目标。分支没有修改 C++，但不能据此声称已在 worktree 全量重编所有 C++。

## 正式宿主走查

VS x64 developer 环境，QT_QPA_PLATFORM=windows；每次只启动一个绝对路径 exe，未用 offscreen。auto exit=1（3.01s），modeling-tour exit=0（8.38s），requirements-tour exit=0（11.16s）；原始 stdout、截图和工程包保留。

auto 红已对照源码：UiPlugin.cpp step4 固定期待 3 模块，实际 6；step7 固定期待 10 建模命令，实际 11。属于旧冒烟断言与当前装配数量不一致，仍登记 FAIL，后继修复须从正式描述符核对，不能任意删除断言。

modeling-tour 包含改为七轴并导出，不是 synthetic6r 基线。requirements-tour 二次应用与撤销/重做成功；没有运行真实可达性评估，日志明确 grid-honest-absent，不能据此关闭 F-495。

截图可见纵向 Dock 堆叠、视窗主要为空网格/区域框：这些是可用性观察，尚未完成研发用户任务试验，也不代替机器人三维完整呈现验证。

## 执行编排与复现

证据包内 run-baseline.ps1 是本轮保留完整日志、XML、原生 JSON 的等价编排，不是原版 gate-all.ps1 已执行的声明。它递归发现 CTestTestfile，并为每个目标单独 ctest；Windows GUI 在串行测试中一次仅一 executable。600 秒是运行上限，不是更改 NFR 性能阈值。

门禁复现：工作树根运行 `cmake --build build --config Release --target ird_gates`；独立使用 Qt/vcpkg 的实际绝对路径配置，再运行同目标。新 worktree 需从源码 bin 复制 ignored ini 模板；不修改框架 tracked 文件。

下一步：独立全新上下文按 acceptance-protocol.md 验收 WP-01-T05，由所有者决定合入。契约保持 ready；首批包不因门禁转绿自动收口。
''')
findings=read(repo/'RobWork/doc/industrial-robot-design/traceability/findings.json')['findings']
priority=[x for x in findings if x['status']=='open' and x['severity'] in ('blocking','major')]
rows=[]
for f in priority:
    fid=f['id']; observed='本轮未定向复现；基线测试通过也不代表本条已修'
    if fid=='F-495': observed='已有 UI-T64/T65、FIX-T1 交付记录；本轮 tour 未触真实评估点着色，owner 宿主闭环未验'
    if fid in ['F-554','F-557','F-558']: observed='主线含 398d39a7 F-id 回归；本轮 ui_test 运行证据见矩阵，未把旧账自动翻牌'
    if fid=='F-795': observed='70f08cfcca8f30237d8d923f0d0b3d1d3f8ffffc 已修且合入；独立验收 E2-DT-20261015；本轮未重演 Debug 必红'
    if fid=='F-714': observed='框架无目标全构建未执行；本轮仅 industrialrobot 目标＋studio，不覆盖此示例'
    if fid=='F-814': observed='源码 exceedsLimit 仍为 actual>limit+tol；仅静态核实，未执行四象限反例'
    if fid=='F-815': observed='源码 computedAtUtc 进入 canonical/contentIdentity；仅静态核实，未执行两次构建反例'
    tasks=[]
    for p in (doc/'tasks/foundation').glob('*.json'):
        if fid in p.read_text(encoding='utf-8-sig'): tasks.append(p.stem)
    rows.append([fid,f['severity'],f['title'],', '.join(tasks) or '尚未匹配专属后继',observed])
write('qp-00-reconciliation.md','''# QP-00 历史缺陷与修复队列

日期：2026-10-15；只读账面快照 820 条，open 502（blocking 1/major 21/minor 8/suggestion 472）。此表是 findings.json 的追溯视图，不是第二份权威缺陷账；没有自行改 fixed。全部 22 个开放高等级条目列入索引，未复现者明确未执行。

'''+table(['编号','等级','账面问题','契约文本引用（不等于已修）','本轮证据/边界'],rows)+'''
## 已复现但历史等级为 minor 的数值问题

F-784：真实 runtime Release 库对小尺度非对称惯量误放、大尺度容差内惯量误拒，双向探针见 qp-02-model-truth.md。后继 RT-T16（DTB WP-06-T16），仅 ready 未实施，不重复新建 finding。

## 首批处理顺序

1. WP-01-T05：22 门禁误分类，已实施/自测，待独立验收；不给性能测试通用跨域许可。
2. RT-T16：F-784 相对惯量判据，两入口一致、对称化后严格 SPD；待独立实施上下文。
3. QP-07.01 服务接线缺口：先查已有宿主装配后继，再立 optimization/ui 接线契约，不能因面板可见就认为能计算。
4. QP-00 宿主 auto 断言老化与原生 JSON 监听器缺口：后继分别界定 UI/测试留痕允许面；不修改本轮唯一产品契约以外源码。
5. F-814/F-815：下一轮先建立可运行反例，不凭静态行号消账；F-795 只对账，不再重复修复已合入守卫。

上表部分历史条目可能已被更早修复覆盖；缺修复 SHA/独立验收/当前复测的条目保持待核对。现有高等级开放数不能直接等同当前真实缺陷数，也不能仅因套件通过批量关闭。
''')
inv=read(run/'reference/golden-inventory.json')
invrows=[]
for x in inv:
    ref=x.get('referenceSource') or {}
    gen=x.get('generator') or {}
    invrows.append([x['datasetId'],x['kind'],ref.get('method','未声明'),ref.get('independentOfProductionImpl','未声明'),gen.get('script','无')])
write('golden-source-inventory.md','# 既有黄金数据来源盘点\n\n29 个数据集的 manifest 声明摘录；118 文件 hash/size 已实算全匹配。independentOfProductionImpl 是原数据声明，不等于本轮逐行审核其生成器；本轮另写标准库独立参考核对 FK/合成物性。fixture 只能证明契约场景，不能自动充当物理解析真值。既有仓内数据沿用仓库许可，无 Isaac/厂商资产导入。\n\n'+table(['数据集','种类','参考法','声明独立','生成器'],invrows))
ref=read(run/'reference/reference-results.json')
poses=ref['goldenPoseComparison']
pe=max(p['maxPositionErrorM'] for p in poses); re_=max(p['maxRotationElementError'] for p in poses)
write('qp-01-case-manifest.md',f'''
# QP-01 六轴输入草案与移交清单

日期 2026-10-15；资产版本 six-axis-v1，状态为合成解析输入草案，未冻结为正式研发工程基线。原始资产见 [inputs.json](assets/six-axis-v1/inputs.json)、[URDF](assets/six-axis-v1/synthetic-6r.urdf)、[独立参考程序](assets/six-axis-v1/reference.py)。input SHA-256 `{ref['inputSha256']}`。

## 来源与可复用性

[29 数据集来源清单](golden-source-inventory.md)及 golden-integrity.json 记录 118 文件的实际哈希/size，全匹配。mdl-template-6r 与 mdl-urdf-import 用于模板/导入契约；kin-fk-analytic 提供六轴局部变换与独立位姿；dyn-two-link-analytic 仅二连杆解析物理参考；sel-catalog-golden 是合成目录测试，不是可直接采购的厂商目录。这些数据不能简单拼接后宣称真实六轴整机已验收。

本轮六轴几何来自仓内 six-axis FK 案，质量/质心/惯量由明确尺寸的合成长方体生成，未引入外部许可资产。URDF effort=100 只是字段测试值，不是驱动能力。无真实厂商参数、效率曲线或实测误差承诺。

## 输入约定

长度 m、角度 rad、质量 kg、惯量 kg·m²、时间 s。关节 origin 为父连杆局部平移；axis 为关节局部单位轴。六轴 Z/Y/Y/X/Y/X；TCP 在法兰系平移 [0.15,0,0.1]，绕 Z 旋转 π/2。惯量参考点为质心，主轴平行所属连杆系；移轴只输出独立参考，不冒充产品已消费。

安装世界位移 [0.2,-0.1,0.05]，地装 I、墙装 Ry(π/2)、倒挂 Rx(π)；重力世界系 [0,0,-9.80665] m/s²。合成 payload 0/2 kg 与工具参数分别列明。可缺/估算字段不以 0 替代，真实目录仍 missing。

## 实际产品路径

import-probe 调用真实 ModelImportMapper.mapUrdf：axes=6、errors=0、submittable=1；checkInvariants=0。RobotDesignCodec 编码后经 ProjectStoreFactory.createNew→DraftService.save→关闭→只读 open→tryLoad，六轴草稿载荷 5236 个十六进制字符逐字节一致，projectId 不变。有效工程在证据包 reference-draft-v5.rwdesign/。

探针自行装配资源快照（真实计算 SHA-256），不代替完整 io 向导；尚未执行该草稿的正式 apply/编译/运动学评估，也未创建基线只读＋方案分支结构。两次早期失败均因探针版本字段使用 1 而非 kSchemaVersionCurrent；首版还缺时间戳，原日志保留，修正契约输入后通过；不作为产品缺陷登记。

宿主 modeling-tour 导出的 mtour-export.irdbundle 另存证据包，走查模型已编辑为七轴，因此不是本六轴资产的正式导出。只读重开探针成功不等同所有 GUI 新建/导入路径通过。

## S1～S8 状态

| 场景 | 本轮已有 | 剩余验证 |
| --- | --- | --- |
| S1 基线重建 | 六轴 URDF/输入、真实导入与草稿重开、6 组独立 FK 对照（含 2 组六轴） | 正式 apply/编译、模型三维、基线分支资格 |
| S2 范围改型 | 合成输入和场景变更说明 | Must 区域/任务、真评估/覆盖/结果着色 |
| S3 工具负载 | 非零 TCP、合成 0/2kg、三种安装参考 | 正式动力学与编译链逐值对照 |
| S4 节拍 | 输入草案 | 完整任务循环、轨迹/驻留/时间参考 |
| S5 器件替换 | 既有合成目录来源盘点 | 真实目录、四象限与回填复算 |
| S6 方案比较 | 既有 OPT-B/D 契约盘点 | 宿主 run 服务、至少两个真实候选/采用 |
| S7 不足与修复 | 惯量误判复现、来源缺口标记 | 正式失败 UI 与修复后恢复 |
| S8 保存/恢复 | 草稿保存、只读重开、宿主撤销/重做走查 | 取消/切换迟到回调、分支/包跨机器 |

## 独立参考复现

在仓库根：`python RobWork/doc/industrial-robot-design/traceability/engineering-polish/assets/six-axis-v1/reference.py --repo . --out <输出目录>`。仅 Python 标准库，无产品库调用。6 组 FK（4 个平面二轴、2 个六轴）与仓内 expected 最大平移误差 {pe:.6g} m、旋转元素误差 {re_:.6g}；另产出 9 组六轴安装姿态参考与 8 个部件物性。

移交只需仓库黄金数据＋本目录 3 个输入/程序文件；工程草稿载荷内含设计，URDF 无外部 mesh。真正跨机器导入/正式资源固化/基线分支仍未执行。QP-01.03/.04 未整体完成，不以合成资产替代实机资格。
''')
write('qp-02-model-truth.md',f'''
# QP-02 单位、物性和编译真值首轮核查

基线 `{base}`，日期 2026-10-15；本轮只读数值核查，无数值产品源码修改。QP-02 整包未收口。

## 已有证据和消费边界

| 链/单元 | 本轮证据 | 未证明范围 |
| --- | --- | --- |
| core 单位/数值 | core_test 原始 XML 与输入 SI/rad 约定 | 全界面输入转换逐字段尚未走查 |
| modeling 导入/物性 | 六轴 URDF 真映射、零不变量违例；既有 modeling/contract/GUI 套件 | 原始草稿正式 apply 与物性回填未执行 |
| runtime 校验/编译 | runtime/contract 套件，F-784 真库探针 | 正式六轴编译后逐帧 FK/NameMap 尚未独立逐项比较 |
| policy/io | 全目标基线中的 policy/io 测试；当前后端静态核实 | 对此六轴的资源缺失、碰撞过滤与损坏文件逐项未审 |
| 变换独立参考 | 6 个 FK 参考（4 个平面二轴、2 个六轴）误差见 QP-01；9 个安装/TCP 参考表 | 9 组尚未对真实产品编译链，DH 非零 α 双向转换仍待审 |
| 物性独立参考 | 8 个长方体解析质心主矩、SPD/三角、平行轴移轴 | 未验证产品非对角惯量旋转/移轴消费全链 |

[逐目标结果](test-target-matrix.md)给出现有套件的本轮执行状态；[281 个相关既有用例索引](model-truth-test-map.json)保留源码行、真实结果及用例名中的显式需求 ID。该索引按相关词检索，非穷尽覆盖，不臆测需求映射或混淆 mock/真实链。不把套件全通过扩成全部数值逻辑正确。

## F-784：真实库双向误判

CanonicalModel.cpp `requireValidInertia` 的对称性用绝对 1e-12，而 REQUIREMENTS §25 附录 D 第 6 项要求相对判据。探针仅借 CanonicalModelFixture 构造其他合法字段，校验调用真实已构建 runtime Release 库。

| 对角 I (kg·m²) | I01 / I10 (kg·m²) | 产品接受 | 相对契约接受 |
| --- | --- | --- | --- |
| 1e-6 | 5e-13 / 0 | 是（误放） | 否 |
| 1e6 | 5e-7 / 0 | 否（误拒） | 是 |

小尺度相对偏差约 2.88675e-7，远超 1e-12；大尺度相对偏差约 2.88675e-13，在容差内。均不能用统一绝对阈值正确判断。源/编译/运行日志入证据包；这是实现对契约的误判，不是物理参数真实性证明。

[RT-T16 后继](../../tasks/foundation/RT-T16.json)已登记 DTB WP-06-T16/units/runtime §12.1：S3 DescriptionValidator 与 S5 builder 一致；对称化后严格 SPD（最小特征值 >0）；测试零范数/非有限/上下尺度/边界，禁止放宽阈值或改变内容身份。状态 ready，未实施/未验收。

## 接下来验证顺序

先修 F-784 并独立验收；随后通过真实六轴 apply/编译核对局部链、base/TCP、NameMap 与 9 组矩阵。再加非对角惯量、非零 DH α、缺外部资源/编译失败的原子性反例；重跑 S1/S2/S3 并将 UI 字段与快照逐项对账。未完成这些前，不冻结 QP-01 的正式工程版本，不开展依赖正确物性资格的选型结论。
''')
write('qp-07-opt-b.md',f'''
# QP-07.01 优化真实接线核查

基线 `{base}`；静态调用链＋正式宿主装配日志，未执行真实候选搜索。QP-07.01 仅完成部分核查，未勾整项。

已有 WP-20-T02～T11 done；WP-21-T01～T04/T06/T07 done；T05/T08 planned，受 P-04 正式判定阈值前置。内核、预检、Pareto、并行、暂停能力继续按已交付子集复核，不将全部 OPT-D 判为未实现。

宿主 ui/plugin/ExtraDomainAssembly.cpp 创建 optimization assembly，只绑定 textResolver 并 registerWithHostRegistrar。仓内定向搜索未找到该宿主随后调用 bindRunStart/bindRunCancel/setServices 的位置。optimization/plugin/OptimizationPluginAssembly.cpp 提供这些 API；OptPanelModel.cpp requestRunStart 在 services.runStart 为空时返回 not-assembled。注册成功/面板可见并不能满足真实开始前置。

正式宿主日志确认 optimization registered=1、panel=1、commands=0；commands=0 是隔离域描述符的设计口径，不能单独当缺陷。缺口依据是 run 服务未绑定。当前尚未建立真实运行→候选→比较→采用闭环证据。

后继先对照 SA-16 与既有宿主接线契约，明确 ui 命令所有权与评估端口；覆盖变量授权/锁定、20 项预检、候选补丁编译、基线、取消和项目切换，再用小空间穷举复核真实候选。不得用人工构造候选或替身端口测试替代宿主执行。
''')
write('qp-09-state-evidence.md','''# QP-09.01 身份与当前性首轮核查

本轮是项目/证据/执行/策略等既有测试和公开 API 草稿重开的局部证据，未完成完整研发结果资格审计。

- 六轴输入以 SHA-256 固定；reference.py 不调用产品计算，参考结果与产品结果分列。
- 真实项目只读重开保持 projectId，草稿 payload 一致；草稿非正式修订，未因保存标正式可用。初始根修订由 createNew 播种，不意味着模型已应用。
- evidence/project/runtime/execution/optimization 的测试状态见矩阵；取消/恢复/过期面现有套件通过也不能替代真实 S6/S8 串联。
- F-815 的 reporting 时间戳进入内容身份路径静态仍在，未做两次真实报告构建，后继先复现；F-816 章节诊断同样未定向核查，不关闭旧账。
- 当前 builtin 碰撞描述符与输入/工况必须参与后续结果资格对账；不能以 CMake 可用后端列表替代实际策略身份。

待审：修改模型/工具/工况后旧结果只保留且标过期；Quick 与 Verified 资格区分；候选预览不改基线；采用时结果与当前快照匹配；取消/切换迟到回调不跨项目污染；报告只消费当前合格证据。以上均不得在当前局部证据上标通过。
''')
units=['core','diagnostics','drivetrain','dynamics','evidence','execution','io','kinematics','modeling','optimization','policy','project','reporting','requirements','runtime','selection','testkit','trajectory','ui','workflow']
cover=[]
limits={'runtime':'F-784 已复现，数值后继待实施','optimization':'宿主 run 服务接线缺口；真实 S6 未完成','selection':'F-814 仅静态核实，未四象限反例','reporting':'F-815/F-816 未动态复现','ui':'auto FAIL；三维着色真评估未执行','modeling':'六轴导入/草稿重开；正式 apply 未执行','testkit':'黄金 manifest hash/size 全匹配，不代表所有参考独立性已审'}
for u in units:
    targets=[r['name'] for r in phases['integration'] if r['name'].startswith('sdurws_ird_'+u+'_')]
    cover.append([u,', '.join(t.replace('sdurws_ird_','') for t in targets) or '被消费者测试使用，无独立登记测试目标',limits.get(u,'只有既有套件本轮基线；贯穿案例逐字段/跨域闭环未审')])
write('unit-review-coverage.md','# 20 单元首批覆盖边界\n\n目标执行状态与内层跳过以 test-target-matrix.md 为准。此表不是 20 单元审核通过证书。\n\n'+table(['单元','本轮集成目标覆盖','工程审核边界'],cover))
write('2026-10-15-first-batch-delivery.md','''# 首批工程打磨交付与验收入口

日期 2026-10-15；实施契约 WP-01-T05，分支 wp01-t05；基线 01223053a130c7b437c6a32f439bdd1c58ba8d54。冻结 main 与框架源码零修改。提交 SHA 以送验提交本身及远程分支 tip 为准；不在提交中自引用未生成 SHA。

## 当前交付

| 工作包 | 产物 | 管理状态 |
| --- | --- | --- |
| QP-00 | 环境/目标/基线、22 高等级索引、门禁修复与先红后绿、后继契约 | 已执行，门禁改动待独立验收；原生 JSON/宿主 auto 尚有缺口 |
| QP-01 | 29/118 完整性、六轴合成模型、独立参考、真导入与草稿重开 | 输入草案已形成，正式 S1～S8 工程未冻结 |
| QP-02 | 单位/参考系/物性审查表、F-784 真库双向复现、RT-T16 | 部分已审；数值修复与真实编译对照待做 |
| QP-07.01 | 优化宿主 run 服务调用链 | 静态缺口已确认；真实候选未执行 |
| QP-09.01 | 输入身份、草稿重开、结果资格边界 | 部分已审，完整跨域链待做 |

索引：[基线](qp-00-baseline.md)、[历史对账](qp-00-reconciliation.md)、[六轴移交](qp-01-case-manifest.md)、[数值核查](qp-02-model-truth.md)、[优化接线](qp-07-opt-b.md)、[身份](qp-09-state-evidence.md)、[20 单元覆盖](unit-review-coverage.md)、[测试矩阵](test-target-matrix.md)。

长期证据：../builds/engineering-polish-first-batch/ 内的 summary、原始日志/XML/原生 JSON/截图/工程包压缩归档与 SHA-256 清单。未执行的项目不列 PASS，原始超时/磁盘失败不覆盖。集成最终 45/45 目标通过（性能补跑），独立 45/45 通过；内部 GUI SKIP、原生 JSON 缺项详见矩阵。

## 独立验收请求

WP-01-T05；基线到 origin/wp01-t05 tip 的完整提交范围。验收者使用全新上下文，按 acceptance-protocol.md 重新配置双模式，复跑门禁与 17 自测；至少抽验未登记跨域、worker 链 testkit 和 L2 链 Qt 必须失败。核查恰两个门禁源码文件变更、7 条测试许可边＋1 条工具边有既有登记依据，禁止通用放行。再核对资产 hash、任务/文档校验与所附证据中的 PASS/FAIL/SKIP/缺 JSON。

本会话未执行独立验收，不自行将契约 ready 改 done，不决定合入。按 AGENTS §6.4 的“单会话单契约”，RT-T16 仅完成立卡，下一独立实施上下文处理；不在门禁契约夹带数值或优化源码修复。首批三个包不能在当前红项和未审范围下宣布整体收口。
''')
print('reports generated',len(allrows),'target executions; priority index',len(priority),'FK max',pe,re_)
