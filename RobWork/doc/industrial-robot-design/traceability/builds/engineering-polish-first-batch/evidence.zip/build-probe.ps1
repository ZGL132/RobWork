$ErrorActionPreference='Stop'
& 'D:/software/Microsoft Visual Studio/2022/Community/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$repo='D:/10_Source_Repos/21_robot/RobWork'
$out="$repo/build/engineering-polish/20261015-first-batch"
$env:PATH="D:/software/Qt/6.11.1/msvc2022_64/bin;$repo/vcpkg/installed/x64-windows/bin;D:/software/Miniconda3;$repo/build/RobWorkStudio/bin/Release;$repo/build/RobWork/bin/Release;$repo/build/RobWorkSim/bin/Release;$env:PATH"
[xml]$project=Get-Content "$repo/build/RobWorkStudio/src/rwslibs/industrialrobot/runtime/sdurws_ird_runtime_test.vcxproj"
$definition=$project.Project.ItemDefinitionGroup | Where-Object Condition -like '*Release|x64*' | Select-Object -First 1
$includes=@($definition.ClCompile.AdditionalIncludeDirectories -split ';' | Where-Object { $_ -notlike '*%(*' } | ForEach-Object { '/I'+$_ })
$libraries=@($definition.Link.AdditionalDependencies -split ';' | Where-Object { $_ -notlike '*%(*' } | ForEach-Object { if ($_ -like '..*') { [IO.Path]::GetFullPath((Join-Path "$repo/build/RobWorkStudio/src/rwslibs/industrialrobot/runtime" $_)) } else { $_ } })
Set-Location $out
& cl /nologo /utf-8 /std:c++17 /EHsc /MD /O2 /DNDEBUG /DNOMINMAX /DGTEST_LINKED_AS_SHARED_LIBRARY=1 /DBOOST_ALL_NO_LIB @includes "/I$repo/vcpkg/installed/x64-windows/include" "/I$repo/RobWork/RobWorkStudio/src/rwslibs/industrialrobot/runtime/test" inertia-probe.cpp /Fe:inertia-probe.exe /link @libraries *> "$out/inertia-probe-build.log"
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
& "$out/inertia-probe.exe" *> "$out/inertia-probe-run.log"
exit $LASTEXITCODE



