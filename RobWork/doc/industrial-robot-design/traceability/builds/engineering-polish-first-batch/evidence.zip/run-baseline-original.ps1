param([string]$Phase = 'integration')
$ErrorActionPreference = 'Stop'
$repo = 'D:/10_Source_Repos/21_robot/RobWork'
$out = "$repo/build/engineering-polish/20261015-first-batch"
& 'D:/software/Microsoft Visual Studio/2022/Community/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$env:QT_QPA_PLATFORM = 'windows'
$env:PATH = "D:/software/Qt/6.11.1/msvc2022_64/bin;$repo/vcpkg/installed/x64-windows/bin;D:/software/Miniconda3;$repo/build/RobWorkStudio/bin/Release;$env:PATH"
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$env:GTEST_CATCH_EXCEPTIONS = '1'
Set-Location $repo
function Invoke-Logged([string]$Label, [string]$Exe, [string[]]$Arguments) {
    $log = "$out/$Phase-$Label.log"
    & $Exe @Arguments 2>&1 | Out-File -FilePath $log -Encoding utf8
    $code = $LASTEXITCODE
    Write-Host "$Phase $Label exit=$code log=$log"
    return $code
}
if ($Phase -eq 'integration') {
    $tree = "$repo/build"
    $scan = "$tree/RobWorkStudio/src/rwslibs/industrialrobot"
    $envData = [ordered]@{
        sha = (git rev-parse HEAD); branch = (git branch --show-current)
        utc = (Get-Date).ToUniversalTime().ToString('o')
        status = @(git status --short)
        vs = $env:VSINSTALLDIR; targetArch = $env:VSCMD_ARG_TGT_ARCH
        qtPlatform = $env:QT_QPA_PLATFORM; qtPrefix = 'D:/software/Qt/6.11.1/msvc2022_64'
        pythonDll = (Get-Item D:/software/Miniconda3/python313.dll).FullName
        zlibDll = (Get-Item D:/software/Miniconda3/zlib.dll).FullName
        cmake = (& cmake --version | Select-Object -First 1)
        cpu = @(Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors)
        os = (Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,TotalVisibleMemorySize)
        occupied = @(Get-Process cmake,ctest,MSBuild,RobWorkStudio,sdurws_ird_studio -ErrorAction SilentlyContinue | Select-Object ProcessName,Id)
        inheritedQt = @(Get-ChildItem Env: | Where-Object Name -match '^(QT_|QML_)' | Select-Object Name,Value)
    }
    $envData | ConvertTo-Json -Depth 6 | Set-Content "$out/environment.json" -Encoding utf8
    Copy-Item "$tree/CMakeCache.txt" "$out/integration-CMakeCache.txt"
    $gateCode = Invoke-Logged 'gates' 'cmake' @('--build',$tree,'--config','Release','--target','ird_gates')
} else {
    $tree = "$out/smoke"
    $scan = $tree
    $configureCode = Invoke-Logged 'configure' 'cmake' @('-S',"$repo/RobWork/RobWorkStudio/src/rwslibs/industrialrobot",'-B',$tree,'-G','Visual Studio 17 2022','-A','x64',"-DCMAKE_TOOLCHAIN_FILE=$repo/vcpkg/scripts/buildsystems/vcpkg.cmake",'-DCMAKE_PREFIX_PATH=D:/software/Qt/6.11.1/msvc2022_64')
    if ($configureCode -ne 0) { exit $configureCode }
}
$map = @{}
Get-ChildItem $scan -Recurse -Filter CTestTestfile.cmake | ForEach-Object {
    $regDir = $_.DirectoryName
    Get-Content $_.FullName | ForEach-Object {
        if ($_ -match 'add_test\((sdurws_ird_[A-Za-z0-9_]+)\s') { $map[$Matches[1]] = $regDir }
    }
}
$names = @($map.Keys | Sort-Object)
$map | ConvertTo-Json | Set-Content "$out/$Phase-inventory.json" -Encoding utf8
if ($names.Count -eq 0) { throw 'No tests discovered' }
$targets = $names
if ($Phase -eq 'integration') { $targets += 'sdurws_ird_studio' }
$buildCode = Invoke-Logged 'build' 'cmake' (@('--build',$tree,'--config','Release','--parallel','4','--target') + $targets)
if ($buildCode -ne 0) { Write-Host 'Build failed: tests from stale executables will not be reported as current PASS'; exit $buildCode }
$rows = @()
foreach ($name in $names) {
    $testOut = "$out/$Phase/$name"
    New-Item -ItemType Directory -Force $testOut | Out-Null
    $env:GTEST_OUTPUT = "xml:$testOut/gtest.xml"
    $jsonSource = Join-Path $map[$name] 'ird-test-report.json'
    if (Test-Path $jsonSource) { Move-Item $jsonSource "$testOut/prior-ird-test-report.json" }
    $start = Get-Date
    $testCode = Invoke-Logged $name 'ctest' @('--test-dir',$map[$name],'-C','Release','-R',"^$name`$",'-V','--timeout','600','--output-junit',"$testOut/ctest.xml")
    if (Test-Path $jsonSource) { Copy-Item $jsonSource "$testOut/ird-test-report.json" }
    $row = [ordered]@{ name=$name; exit=$testCode; seconds=((Get-Date)-$start).TotalSeconds; status=$(if($testCode -eq 0){'PASS'}else{'FAIL'}); xml=(Test-Path "$testOut/gtest.xml"); json=(Test-Path "$testOut/ird-test-report.json"); log="$Phase-$name.log" }
    $rows += [pscustomobject]$row
    $rows | ConvertTo-Json -Depth 4 | Set-Content "$out/$Phase-results.json" -Encoding utf8
    if ((Get-Content "$out/$Phase-$name.log" -Raw) -match 'no Qt platform plugin could be initialized') { throw 'Qt platform initialization failed: stop and inspect inherited environment' }
}
$rows | Group-Object status | Select-Object Name,Count | Format-Table
if (@($rows | Where-Object exit -ne 0).Count -gt 0 -or ($Phase -eq 'integration' -and $gateCode -ne 0)) { exit 1 }
exit 0

