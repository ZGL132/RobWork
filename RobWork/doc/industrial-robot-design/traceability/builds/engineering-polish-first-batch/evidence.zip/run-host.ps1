$ErrorActionPreference='Stop'
& 'D:/software/Microsoft Visual Studio/2022/Community/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$repo='D:/10_Source_Repos/21_robot/RobWork'
$out="$repo/build/engineering-polish/20261015-first-batch"
$env:QT_QPA_PLATFORM='windows'
$env:PATH="D:/software/Qt/6.11.1/msvc2022_64/bin;$repo/vcpkg/installed/x64-windows/bin;D:/software/Miniconda3;$repo/build/RobWorkStudio/bin/Release;$env:PATH"
$rows=@()
foreach($mode in @('auto','modeling-tour','requirements-tour')) {
    $dir="$out/host-$mode"
    New-Item -ItemType Directory -Force $dir | Out-Null
    $env:IRD_UI_PLUGIN_SMOKE=$mode
    $env:IRD_UI_PLUGIN_SMOKE_OUT=$dir
    $start=Get-Date
    $p=Start-Process -FilePath "$repo/build/RobWorkStudio/bin/Release/sdurws_ird_studio.exe" -ArgumentList '--no-splash' -WorkingDirectory "$repo/build/RobWorkStudio/bin/Release" -WindowStyle Hidden -PassThru -RedirectStandardOutput "$dir/stdout.log" -RedirectStandardError "$dir/stderr.log"
    $timedOut=-not $p.WaitForExit(60000)
    if($timedOut){$p.Kill();$p.WaitForExit()}
    $rows += [pscustomobject]@{mode=$mode;exit=$p.ExitCode;timeout=$timedOut;seconds=((Get-Date)-$start).TotalSeconds}
    $rows | ConvertTo-Json | Set-Content "$out/host-results.json" -Encoding utf8
    Write-Host "$mode exit=$($p.ExitCode) timeout=$timedOut"
    $logs=(Get-Content "$dir/stdout.log","$dir/stderr.log" -Raw) -join "`n"
    if($logs -match 'no Qt platform plugin could be initialized'){throw 'Qt platform failure: inspect inherited environment before continuing'}
    if($mode -ne 'auto') {
        $pattern=if($mode -eq 'modeling-tour'){'ird-mtour-demo-*'}else{'ird-tour-demo-*'}
        $created=Get-ChildItem $env:TEMP -Directory -Filter $pattern | Where-Object CreationTime -ge $start | Sort-Object CreationTime -Descending | Select-Object -First 1
        if($created){ Copy-Item $created.FullName "$dir/project" -Recurse }
    }
}
