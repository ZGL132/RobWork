// QP-02 诊断探针：复用夹具只构造输入，判断调用真实 runtime 库。
// 非正式测试目标，不写产品源码，不作为独立验收替代物。
#include "CanonicalModelFixture.hpp"
#include <iostream>
int main() {
    using namespace sdurws::ird::runtime;
    using namespace sdurws::ird::runtime::testfixture;
    for (const auto scale : {1e-6, 1e6}) {
        auto input = richFixture();
        const double delta = scale == 1e-6 ? 5e-13 : 5e-7;
        input.chain.links.at(1).inertia = core::SourcedValue<rw::math::InertiaMatrix<double>>::provided(
            rw::math::InertiaMatrix<double>(scale,delta,0,0,scale,0,0,0,scale),userProv());
        bool accepted = false;
        try { auto output = input.toBuilder().build(); accepted = true; }
        catch (const RuntimeError&) { }
        std::cout << "scale=" << scale << " delta=" << delta
                  << " productAccepted=" << accepted
                  << " contractAccepts=" << (scale == 1e6) << std::endl;
    }
}
