from pathlib import Path
import json, zipfile, hashlib, shutil
r=Path(r'D:/10_Source_Repos/21_robot/RobWork/build/engineering-polish/20261015-first-batch')
w=Path(r'C:/Users/zgl18/.codex/worktrees/qp00-gate-repair/RobWork')
d=w/'RobWork/doc/industrial-robot-design/traceability/builds/engineering-polish-first-batch'
d.mkdir(parents=True,exist_ok=True)
# 完整保留原始输出；只打包本轮明确的证据目录，不递归收构建树/可执行文件。
dirs=['integration','integration-perf-retry','smoke','host-auto','host-modeling-tour','host-requirements-tour','reference','reference-draft.rwdesign','reference-draft-v2.rwdesign','reference-draft-v3.rwdesign','reference-draft-v4.rwdesign','reference-draft-v5.rwdesign']
# 独立构建已迁往 C 盘；r/smoke 后续仅是 XML/JSON 测试报告。
entries=[p for p in r.iterdir() if p.is_file() and p.suffix in ['.log','.json','.ps1','.cpp','.py']]
for name in dirs:
    root=r/name
    if root.exists(): entries.extend(p for p in root.rglob('*') if p.is_file() and p.suffix not in ['.exe','.obj','.lib','.pdb','.dll'])
entries=sorted(set(entries))
manifest=[]
with zipfile.ZipFile(d/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for p in entries:
        data=p.read_bytes(); rel=p.relative_to(r).as_posix()
        archive.writestr(rel,data)
        manifest.append({'path':rel,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(d/'evidence-files.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['environment.json','integration-inventory.json','integration-results.json','integration-perf-retry-results.json','smoke-inventory.json','smoke-results.json','host-results.json','validate-WP-01-T05.log','validate-RT-T16.log','validate-docs.log','reference-recheck.log']:
    if (r/name).exists() and name.endswith('.json'): shutil.copy2(r/name,d/name)
summary=w/'RobWork/doc/industrial-robot-design/traceability/engineering-polish/test-results-summary.json'
shutil.copy2(summary,d/'test-results-summary.json')
(d/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(d.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'),encoding='utf-8')
print('archive',len(entries),'files', (d/'evidence.zip').stat().st_size,'bytes')
