$ErrorActionPreference='Stop'
& 'D:/software/Microsoft Visual Studio/2022/Community/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$repo='D:/10_Source_Repos/21_robot/RobWork'
$wt='C:/Users/zgl18/.codex/worktrees/qp00-gate-repair/RobWork'
$out="$repo/build/engineering-polish/20261015-first-batch"
$toolchain="$repo/vcpkg/scripts/buildsystems/vcpkg.cmake"
$qt='D:/software/Qt/6.11.1/msvc2022_64'
Set-Location $wt
foreach($path in @("$wt/RobWork/RobWorkStudio/bin","$wt/build/RobWorkStudio/bin")) {
    New-Item -ItemType Directory -Force $path | Out-Null
    Copy-Item "$repo/RobWork/RobWorkStudio/bin/RobWorkStudio.ini.template.static" "$path/RobWorkStudio.ini.template.static"
}
foreach($mode in @('integration','smoke')) {
    $tree=if($mode -eq 'integration'){"$wt/build"}else{"$wt/build-qp00-smoke"}
    $src=if($mode -eq 'integration'){"$wt/RobWork"}else{"$wt/RobWork/RobWorkStudio/src/rwslibs/industrialrobot"}
    [string[]]$extra=if($mode -eq 'integration'){@('-DRWS_BUILD_INDUSTRIALROBOT=ON')}else{@()}
    & cmake -S $src -B $tree -G 'Visual Studio 17 2022' -A x64 "-DCMAKE_TOOLCHAIN_FILE=$toolchain" "-DCMAKE_PREFIX_PATH=$qt" @extra *> "$out/gate-wt-$mode-configure.log"
    $c=$LASTEXITCODE
    Write-Host "worktree $mode configure=$c"
    if($c -ne 0){exit $c}
    & cmake --build $tree --config Release --target ird_gates *> "$out/gate-wt-$mode-build.log"
    $c=$LASTEXITCODE
    Write-Host "worktree $mode gates=$c"
    if($c -ne 0){exit $c}
}

