$ErrorActionPreference='Stop'
& 'D:/software/Microsoft Visual Studio/2022/Community/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$repo='D:/10_Source_Repos/21_robot/RobWork'
$out="$repo/build/engineering-polish/20261015-first-batch"
$env:QT_QPA_PLATFORM='windows'
$env:PATH="D:/software/Qt/6.11.1/msvc2022_64/bin;$repo/vcpkg/installed/x64-windows/bin;D:/software/Miniconda3;$repo/build/RobWorkStudio/bin/Release;$env:PATH"
$target='sdurws_ird_optimization_perf_test'
$dir="$repo/build/RobWorkStudio/src/rwslibs/industrialrobot/optimization"
$dest="$out/integration-perf-retry/$target"
New-Item -ItemType Directory -Force $dest | Out-Null
$env:GTEST_OUTPUT="xml:$dest/gtest.xml"
$start=Get-Date
& ctest --test-dir $dir -C Release -R "^$target`$" -V --timeout 600 --output-junit "$dest/ctest.xml" *> "$out/integration-perf-retry.log"
$code=$LASTEXITCODE
if(Test-Path "$dir/ird-test-report.json"){Copy-Item "$dir/ird-test-report.json" "$dest/ird-test-report.json"}
@{name=$target;exit=$code;seconds=((Get-Date)-$start).TotalSeconds;timeoutSeconds=600} | ConvertTo-Json | Set-Content "$out/integration-perf-retry-results.json" -Encoding utf8
Write-Host "perf retry exit=$code"
if($code -ne 0){exit $code}
& "$out/run-baseline.ps1" -Phase smoke
exit $LASTEXITCODE
