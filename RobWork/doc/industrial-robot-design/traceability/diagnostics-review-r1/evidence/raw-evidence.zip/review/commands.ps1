# 本轮已执行命令的复现配方；此文件是事后整理，不冒充逐行 shell transcript。
# 不要自动整份重跑。现有两个全量目标本轮各已执行一次；后续仅选定向过滤。
$repo = 'C:\Users\zgl18\.codex\worktrees\core-review-fixes\RobWork'
$e = Join-Path $repo 'build\diagnostics-review-20261028'
Set-Location -LiteralPath $repo

# 启动真实执行，原始四条输出见会话；当前再次读取见 site.json。
git rev-parse --show-toplevel
git branch --show-current
git rev-parse HEAD
git status --short

# 已核源码根为本 C: 工作树，工业机械臂开关为 ON；没有重配 D: 源码。
Select-String -LiteralPath (Join-Path $repo 'build\CMakeCache.txt') -Pattern '^CMAKE_HOME_DIRECTORY:','^RWS_BUILD_INDUSTRIALROBOT:','^CMAKE_TOOLCHAIN_FILE:','^VCPKG_INSTALLED_DIR:','^ROBWORK_VERSION:'
cmake --build build --config Release --target sdurws_ird_diagnostics_test *> "$e\build-test.log"
cmake --build build --config Release --target sdurws_ird_diagnostics_contract_test *> "$e\build-contract.log"

# 零 Qt 测试，实际分别启动；依赖供给仅使用既有 vcpkg。
$env:Path = "$repo\build\RobWork\bin\Release;$repo\build\RobWorkStudio\libs\Release;D:\10_Source_Repos\21_robot\RobWork\vcpkg\installed\x64-windows\bin;$env:Path"
& "$repo\build\RobWorkStudio\bin\Release\sdurws_ird_diagnostics_test.exe" "--gtest_output=xml:$e/diagnostics.xml" "--ird_report=$e/diagnostics.ird-test-report.json" *> "$e\diagnostics.log"
& "$repo\build\RobWorkStudio\bin\Release\sdurws_ird_diagnostics_contract_test.exe" "--gtest_output=xml:$e/contract.xml" "--ird_report=$e/contract.ird-test-report.json" *> "$e\contract.log"
# 两组均实际 exit 0；123/123 与 26/26。_report 未执行，以免重复。

Set-Location -LiteralPath $e
cmake -S . -B probe-build -G 'Visual Studio 17 2022' -A x64 *> probe-configure.log
cmake --build probe-build --config Release --target diagnostics_review_probe *> probe-build.log
# 首批源码当时含 12 项；最终源码为追加后的超集，重放首批应显式过滤原六套件。
& "$e\probe-build\Release\diagnostics_review_probe.exe" '--gtest_filter=ReviewFactory.*:ReviewRedaction.*:ReviewLogging.*:ReviewCatalog.*:ReviewCrash.*:ReviewFiles.*' "--gtest_output=xml:$e/probe.xml" "--ird_report=$e/probe.ird-test-report.json" *> probe.log
# 首批实际当时没有过滤（当时总计12项），exit 1：1 passed / 11 failed。

# 追加原装配源与新探针后仅运行新增过滤；build exit 0，test exit 1。
cmake --build probe-build --config Release --target diagnostics_review_probe *> probe-extra-build.log
& "$e\probe-build\Release\diagnostics_review_probe.exe" '--gtest_filter=ReviewWiring.*:ReviewConfirmable.*:ReviewLoggingExtra.*:ReviewAggregation.*:ReviewUtf8.*' "--gtest_output=xml:$e/probe-extra.xml" "--ird_report=$e/probe-extra.ird-test-report.json" *> probe-extra.log

# 再追加过期查询子进程与采样反例；build exit 0，test exit 1。
cmake --build probe-build --config Release --target diagnostics_review_probe *> probe-final-build.log
& "$e\probe-build\Release\diagnostics_review_probe.exe" '--gtest_filter=ReviewConfirmableExtra.*:ReviewLoggingSampling.*' "--gtest_output=xml:$e/probe-final.xml" "--ird_report=$e/probe-final.ird-test-report.json" *> probe-final.log

# 最后追加非法枚举反例；build exit 0，test exit 1。
cmake --build probe-build --config Release --target diagnostics_review_probe *> probe-registry-build.log
& "$e\probe-build\Release\diagnostics_review_probe.exe" '--gtest_filter=ReviewRegistry.*' "--gtest_output=xml:$e/probe-registry.xml" "--ird_report=$e/probe-registry.ird-test-report.json" *> probe-registry.log

# 排除实例 level 错配的输入干扰，再次定向核对目录与聚合（2项）；无全量重跑。
cmake --build probe-build --config Release --target diagnostics_review_probe *> probe-valid-build.log
& "$e\probe-build\Release\diagnostics_review_probe.exe" '--gtest_filter=ReviewValidInputs.*' "--gtest_output=xml:$e/probe-valid.xml" "--ird_report=$e/probe-valid.ird-test-report.json" *> probe-valid.log

# UTF-8 原始字节的独立检查：本轮真实运行，结果 decode FAIL（日志独立保留）。
& 'C:\Users\zgl18\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -X utf8 -c "from pathlib import Path; b=Path('translation-cause.bin').read_bytes(); print('bytes',len(b)); print('cut_hex',b[508:520].hex()); print(b.decode('utf-8',errors='strict'))"

# 本轮并未执行 GUI/全库门禁/独立 smoke/修复/提交。
