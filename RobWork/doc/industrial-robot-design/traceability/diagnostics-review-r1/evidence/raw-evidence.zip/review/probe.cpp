/** 只读评审隔离探针。所有字符串均为合成数据；断言为独立预期，不修改正式测试。 */
#include <sdurws/ird/diagnostics/Factory.hpp>
#include <sdurws/ird/diagnostics/Confirmable.hpp>
#include <sdurws/ird/diagnostics/Logging.hpp>
#include <sdurws/ird/diagnostics/Redaction.hpp>
#include <sdurws/ird/diagnostics/CrashReport.hpp>
#include <sdurws/ird/diagnostics/Aggregation.hpp>
#include <gtest/gtest.h>
#include <atomic>
#include <condition_variable>
#include <fstream>
#include <iostream>
#include <thread>
using namespace sdurws::ird;
using namespace sdurws::ird::diagnostics;
using namespace std::chrono_literals;
namespace fs=std::filesystem;
struct Clock:IClock { std::chrono::system_clock::time_point nowUtc()const override{return std::chrono::system_clock::time_point{1000000s};} };
struct Rig { StableCodeRegistry reg; Clock clock; DiagnosticsFactory factory{reg,clock}; Rig(){registerBuiltinCodes(reg);} };
DiagContext ctx(){DiagContext c; c.sourceUnit="review";c.sourceInterface="probe";return c;}
core::DiagnosticRecord rec(std::string code="RT-INPUT-INVALID",core::ObjectId id=core::ObjectId::generate()) {return core::DiagnosticRecord::make(code,id,{}, {},"synthetic context","synthetic cause","synthetic action");}
struct MemoryOps:ILogFileOps {std::mutex mutex;std::vector<std::string> lines;std::atomic<int> flushes{0};bool appendLine(const fs::path&,std::string_view s)override{std::lock_guard<std::mutex> l(mutex);lines.emplace_back(s);return true;}bool flushFile(const fs::path&)override{++flushes;return true;}bool rotateFile(const fs::path&,std::uint32_t)override{return true;}std::uint64_t fileSize(const fs::path&)override{return 0;}};
LogSinkConfig cfg(){LogSinkConfig c;c.directory="synthetic-review-directory";c.userEnabled=false;c.throttleWindowSeconds=0;c.sampleEveryDebug=1;return c;}
LogRecord logrec(std::string msg){LogRecord r;r.tier=LogTier::Dev;r.level=LogLevel::Info;r.channel="review/probe";r.message=std::move(msg);return r;}
TEST(ReviewFactory, StableCodeBlockingLevelCannotBeDowngraded){Rig x;auto r=rec();r.level=core::DiagnosticLevel::Warning;auto e=x.factory.create(r,ctx());std::cout<<"code="<<e.record.code<<" descriptor="<<int(x.reg.find(r.code)->level)<<" record="<<int(e.record.level)<<'\n';EXPECT_EQ(e.record.level,x.reg.find(r.code)->level);}
TEST(ReviewRedaction, JsonQuotedCredentialAndKeyAreRemoved){RedactionService red;for(auto raw:{R"({"password":"FakePassword918"})","key=FakeKey927","password=FakeOk928"}){auto out=red.redact(raw,LogTier::Dev);std::cout<<"input="<<raw<<" output="<<out<<'\n';EXPECT_EQ(out.find("Fake"),std::string::npos);}}
TEST(ReviewRedaction, RootOnlyIsIdempotent){RedactionService red;auto a=red.redact(R"(D:\synthetic\private\robot.stl)",LogTier::Dev);auto b=red.redact(a,LogTier::Dev);std::cout<<"first="<<a<<" second="<<b<<'\n';EXPECT_EQ(a,b);}
TEST(ReviewLogging, InternalChannelAndMetadataStillRedact){Clock clock;MemoryOps ops;LoggingPipeline p(clock,ops);p.configure(cfg());p.attachRedactionService(std::make_shared<RedactionService>());p.log(logrec("password=FakeNormal928"));auto a=logrec("password=FakeInternal929");a.channel="diag/logging";p.log(a);auto b=logrec("safe");b.threadTag="password=FakeTag930";p.log(b);auto c=logrec("safe");c.channel="review\nFORGED password=FakeChan931";p.log(c);ASSERT_TRUE(p.flush(2s));for(auto& s:p.devTailSnapshot(20)){std::cout<<s<<'\n';EXPECT_EQ(s.find("Fake"),std::string::npos);EXPECT_EQ(s.find('\n'),std::string::npos);}}
TEST(ReviewCatalog, IncomingCauseProtectsConsumedRoot){Rig x;DiagCatalog cat;cat.configureCapacity({true,1});auto a=x.factory.create(rec("RT-CANCELLED"),ctx());auto root=a.entryId;cat.append(a);cat.markConsumed(root);auto b=x.factory.create(rec(),ctx());b.causedBy=root;cat.append(b);auto v=cat.snapshot({});std::cout<<"root="<<root<<" catalogSize="<<v.size()<<" surviving="<<v.front().entryId<<'\n';EXPECT_EQ(v.size(),2u);}
TEST(ReviewCatalog, ConcurrentArrivalUsesOrderKey){Rig x;DiagCatalog cat;auto a=x.factory.create(rec(),ctx());auto b=x.factory.create(rec(),ctx());cat.append(b);cat.append(a);auto v=cat.snapshot({});std::cout<<"created="<<a.entryId<<","<<b.entryId<<" snapshot="<<v[0].entryId<<","<<v[1].entryId<<'\n';EXPECT_EQ(v[0].entryId,a.entryId);}
TEST(ReviewCatalog, RevisionQueryDoesNotLoseNewOccurrence){Rig x;DiagCatalog cat;auto id=core::ObjectId::generate();auto c=ctx();c.revision=core::RevisionId::generate();auto a=x.factory.create(rec("RT-INPUT-INVALID",id),c);cat.append(a);c.revision=core::RevisionId::generate();auto b=x.factory.create(rec("RT-INPUT-INVALID",id),c);cat.append(b);DiagQuery q;q.revision=c.revision;std::cout<<"all="<<cat.size()<<" newRevision="<<cat.snapshot(q).size()<<'\n';EXPECT_EQ(cat.snapshot(q).size(),1u);}
TEST(ReviewFactory, TranslationTruncationPreservesUtf8){Rig x;auto c=ctx();std::runtime_error err(std::string(511,'a')+u8"中文");auto a=x.factory.translate(err,c);auto pos=a.record.cause.find(u8"中");std::cout<<"cause_size="<<a.record.cause.size()<<" prefix_last_byte="<<std::hex<<int(static_cast<unsigned char>(a.record.cause[511]))<<std::dec<<'\n';EXPECT_NE(pos,std::string::npos);}
TEST(ReviewLogging, WorkerFinalDiscardsAlreadyBufferedLaterBatches){Clock clock;MemoryOps ops;LoggingPipeline p(clock,ops);p.configure(cfg());core::TaskIdentity t{core::ProjectId::generate(),core::BranchId::generate(),core::RevisionId::generate(),core::RunId::generate(),core::AttemptId::fromCanonical("att-1")};WorkerLogBatch later{1,t,1,false,{logrec("LATE_AFTER_FINAL")}};p.replayWorkerBatch(later);WorkerLogBatch final{1,t,0,true,{logrec("FINAL")}};p.replayWorkerBatch(final);ASSERT_TRUE(p.flush(2s));for(auto&s:p.devTailSnapshot(20)){std::cout<<s<<'\n';EXPECT_EQ(s.find("LATE_AFTER_FINAL"),std::string::npos);}}
TEST(ReviewLogging, FlushDeadlineIncludesFileFlush){Clock clock;struct Slow:MemoryOps{bool flushFile(const fs::path&)override{std::this_thread::sleep_for(250ms);return true;}}ops;LoggingPipeline p(clock,ops);p.configure(cfg());p.log(logrec("test"));auto start=std::chrono::steady_clock::now();auto ok=p.flush(20ms);auto ms=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-start).count();std::cout<<"requested=20ms elapsed="<<ms<<" result="<<ok<<'\n';EXPECT_LT(ms,100);}
TEST(ReviewCrash, SameTimestampReportsHaveDistinctFiles){Clock clock;FileLogFileOps ops;RedactionService red;CrashReportWriter w(red,clock,ops);auto dir=fs::current_path()/"probe-crash-collision";CrashReportInput in;in.processId=77;in.exceptionMessage="first";auto a=w.write(in,dir);in.exceptionMessage="second";auto b=w.write(in,dir);ASSERT_TRUE(a);ASSERT_TRUE(b);std::cout<<"first="<<a->u8string()<<" second="<<b->u8string()<<'\n';EXPECT_NE(*a,*b);}
TEST(ReviewFiles, UnicodePathPreserved){FileLogFileOps ops;auto dir=fs::current_path()/fs::u8path(u8"probe-unicode-机器人-🤖");fs::create_directories(dir);auto file=dir/"test.log";bool ok=false;try{ok=ops.appendLine(file,"synthetic");}catch(const std::exception&e){std::cout<<"exception="<<e.what()<<'\n';}std::cout<<"append="<<ok<<" requestedPathExists="<<fs::exists(file)<<'\n';EXPECT_TRUE(ok&&fs::exists(file));}
#include <future>
#include <sdurws/ird/ui/IWorkbenchShell.hpp>
#include "../../RobWork/RobWorkStudio/src/rwslibs/industrialrobot/ui/app/DiagnosticsAssembly.hpp"
// 仅 UI 码表供体为空替身；被测 assembleDiagnostics.cpp 原件直接编译，日志/脱敏/工厂/目录均为真实实现。
namespace sdurws::ird::ui {std::vector<diagnostics::CodeDescriptor> uiDiagnosticCodeDescriptors(){return {};}}
TEST(ReviewWiring, ProductionAssemblyRedactsBeforeDisk){ui::app::DiagnosticsStack s;auto dir=fs::current_path()/"probe-real-assembly";ui::app::assembleDiagnostics(dir,s);s.pipeline->log(logrec("password=FakeAssembly932"));ASSERT_TRUE(s.pipeline->flush(2s));std::ifstream f(dir/"dev-diagnostics.log",std::ios::binary);std::string txt((std::istreambuf_iterator<char>(f)),{});std::cout<<txt;EXPECT_EQ(txt.find("FakeAssembly932"),std::string::npos);}
struct Env:IConfirmationEnvironment{core::RevisionId rev=core::RevisionId::generate();core::ContentIdentity cmd;Env(){cmd.bytes.fill(1);}core::RevisionId currentTipRevision(core::ProjectId,core::BranchId)const override{return rev;}std::optional<core::ContentIdentity> currentPolicyContentId(core::ProjectId,core::BranchId)const override{return {};}std::optional<core::ContentIdentity> currentCommandDigest(core::ProjectId,core::BranchId)const override{return cmd;}};
CodeDescriptor confirmDescriptor(){CodeDescriptor d;d.code="MDL-REVIEW-CONFIRM";d.ownerUnit="modeling";d.category=DiagnosticCategory::Confirmable;d.severity=DiagnosticSeverity::Warning;d.level=core::DiagnosticLevel::Warning;d.titleKey="diag.mdl-review-confirm.title";d.detailKey="diag.mdl-review-confirm.detail";d.paramSchema="[]";d.confirmable=true;d.requiresComparison=true;return d;}
core::ConfirmableFinding finding(){auto r=rec("MDL-REVIEW-CONFIRM");r.level=core::DiagnosticLevel::Warning;auto unit=*core::UnitToken::find("rad");auto val=[&](double n){return core::ComparativeValue{core::SourcedValue<double>::provided(n,core::ValueProvenance::make(core::ProvenanceKind::UserProvided)),unit};};r.comparison=core::ComparativeFields{val(20),val(12)};return core::ConfirmableFinding::make(r);}
TEST(ReviewConfirmable, LoggingFailureDoesNotReplaceConfirmationOutcome){Rig x;x.reg.registerCode(confirmDescriptor());Env env;struct Sink:IDevLogSink{bool fail=false;void logDev(std::string_view,std::string)override{if(fail)throw std::runtime_error("synthetic sink failure");}}sink;ConfirmableService svc(x.reg,env,x.clock,&sink);auto f=finding();auto r=svc.create(f,"review",env.cmd,core::ProjectId::generate(),core::BranchId::generate(),env.rev,{}, {*f.record.subject});sink.fail=true;bool threw=false;try{svc.submitConfirmation(r.findingId,r.callbackToken,{"SyntheticReviewer",x.clock.nowUtc()});}catch(const std::exception&e){threw=true;std::cout<<"exception="<<e.what()<<'\n';}auto after=svc.tryFind(r.findingId);std::cout<<"threw="<<threw<<" state="<<int(after->state)<<" token="<<after->callbackToken<<'\n';EXPECT_FALSE(threw);}
TEST(ReviewLoggingExtra, FullHighPriorityQueueKeepsError){Clock clock;struct Gate:MemoryOps{std::mutex g;std::condition_variable cv;bool enter=false,open=false;bool appendLine(const fs::path&p,std::string_view s)override{{std::unique_lock<std::mutex>l(g);enter=true;cv.notify_all();cv.wait(l,[&]{return open;});}return MemoryOps::appendLine(p,s);}}ops;LoggingPipeline p(clock,ops);auto c=cfg();c.queueCapacity=2;p.configure(c);auto a=logrec("INFLIGHT");a.level=LogLevel::Error;p.log(a);{std::unique_lock<std::mutex>l(ops.g);ASSERT_TRUE(ops.cv.wait_for(l,2s,[&]{return ops.enter;}));}for(auto msg:{"ERROR_QUEUED_A","ERROR_QUEUED_B","ERROR_DROPPED_C"}){a.message=msg;p.log(a);} {std::lock_guard<std::mutex>l(ops.g);ops.open=true;ops.cv.notify_all();}ASSERT_TRUE(p.flush(2s));std::string all;for(auto&s:p.devTailSnapshot(20)){std::cout<<s<<'\n';all+=s;}EXPECT_NE(all.find("ERROR_DROPPED_C"),std::string::npos);}
TEST(ReviewLoggingExtra, DestructionHonorsThreeSecondDrainBudget){Clock clock;struct Slow:MemoryOps{bool appendLine(const fs::path&p,std::string_view s)override{std::this_thread::sleep_for(20ms);return MemoryOps::appendLine(p,s);}}ops;auto p=std::make_unique<LoggingPipeline>(clock,ops);auto c=cfg();c.flushEveryLines=0;c.flushInterval=0ms;p->configure(c);for(int i=0;i<180;++i)p->log(logrec("synthetic "+std::to_string(i)));auto start=std::chrono::steady_clock::now();p.reset();auto ms=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-start).count();std::cout<<"drainBudget=3000ms elapsed="<<ms<<" perAppend=20ms count=180\n";EXPECT_LT(ms,3300);}
TEST(ReviewAggregation, SameCauseRootDoesNotMergeAcrossTasks){Rig x;auto c1=ctx();auto c2=ctx();core::TaskIdentity t{core::ProjectId::generate(),core::BranchId::generate(),core::RevisionId::generate(),core::RunId::generate(),core::AttemptId::fromCanonical("att-1")};c1.task=t;t.attempt=core::AttemptId::fromCanonical("att-2");c2.task=t;auto root=x.factory.create(rec(),c1);auto a=x.factory.create(rec("RT-RESOURCE-MISSING"),c1);auto b=x.factory.create(rec("RT-RESOURCE-MISSING"),c2);a.causedBy=root.entryId;b.causedBy=root.entryId;DiagnosticAggregator ag;auto v=ag.aggregate({root,a,b},{});for(auto&g:v){std::cout<<"group count="<<g.members.size()<<'\n';EXPECT_EQ(g.members.size(),1u);}}
TEST(ReviewUtf8, TranslationPrefixDecodes){Rig x;std::runtime_error err(std::string(511,'a')+u8"中文");auto a=x.factory.translate(err,ctx());auto path=fs::current_path()/"translation-cause.bin";std::ofstream out(path,std::ios::binary);out<<a.record.cause;out.close();std::cout<<"rawCauseFile="<<path.u8string()<<" byte511="<<int(static_cast<unsigned char>(a.record.cause[511]))<<" byte512="<<int(static_cast<unsigned char>(a.record.cause[512]))<<'\n';EXPECT_FALSE(static_cast<unsigned char>(a.record.cause[511])==0xe4 && static_cast<unsigned char>(a.record.cause[512])!=0xb8);}

// 只在 gtest 子进程中触发终止，主评审进程有界回收；退出码证明具体 logger 异常路径。
void expiredQueryWithThrowingSink(){
    std::set_terminate([]{std::_Exit(86);});
    Rig x;x.reg.registerCode(confirmDescriptor());Env env;
    struct Sink:IDevLogSink{bool fail=false;void logDev(std::string_view,std::string)override{if(fail)throw std::runtime_error("synthetic expiration sink failure");}}sink;
    ConfirmableService svc(x.reg,env,x.clock,&sink);auto f=finding();
    auto r=svc.create(f,"review",env.cmd,core::ProjectId::generate(),core::BranchId::generate(),env.rev,{}, {*f.record.subject});
    svc.armExpiration(r.findingId,x.clock.nowUtc());sink.fail=true;
    static_cast<void>(svc.tryFind(r.findingId));std::_Exit(0);
}
TEST(ReviewConfirmableExtra, ExpiringNoexceptQueryTerminatesOnSinkFailure){
    EXPECT_EXIT(expiredQueryWithThrowingSink(),::testing::ExitedWithCode(86),"");
}
TEST(ReviewLoggingSampling, LastAlreadySelectedDoesNotReplayEarlierTail){
    Clock clock;MemoryOps ops;
    {LoggingPipeline p(clock,ops);auto c=cfg();c.sampleEveryDebug=4;p.configure(c);
    for(int i=1;i<=4;++i){auto r=logrec("SAMPLE_"+std::to_string(i));r.level=LogLevel::Debug;p.log(r);}}
    std::string all;for(auto&s:ops.lines){std::cout<<s<<'\n';all+=s;}
    EXPECT_EQ(all.find("SAMPLE_3"),std::string::npos);
}
TEST(ReviewRegistry, InvalidCategoryIsRejectedBeforeManifest){
    Rig x;auto good=*x.reg.find("RT-INPUT-INVALID");auto bad=good;
    bad.category=static_cast<DiagnosticCategory>(255);
    StableCodeRegistry a,b;a.registerCode(good);bool rejected=false;
    try{b.registerCode(bad);}catch(const DiagnosticsError&){rejected=true;}
    std::cout<<"invalidCategoryRejected="<<rejected;
    if(!rejected)std::cout<<" stored="<<int(b.find(bad.code)->category)<<" sameManifest="<<(a.manifest()==b.manifest());
    std::cout<<'\n';EXPECT_TRUE(rejected);
}
// 消除与 D04 的交叉：输入级别先与注册表一致，单独验证目录/聚合根因。
TEST(ReviewValidInputs, IncomingReferenceProtectsCanonicalRoot){
    Rig x;DiagCatalog cat;cat.configureCapacity({true,1});
    auto r=rec("RT-CANCELLED");r.level=x.reg.find(r.code)->level;
    auto a=x.factory.create(r,ctx());cat.append(a);cat.markConsumed(a.entryId);
    auto b=x.factory.create(rec(),ctx());b.causedBy=a.entryId;cat.append(b);
    std::cout<<"canonical rootLevel="<<int(a.record.level)<<" root="<<a.entryId<<" catalogSize="<<cat.size()<<'\n';
    EXPECT_EQ(cat.size(),2u);
}
TEST(ReviewValidInputs, CatalogAcceptedCausesRemainPartitioned){
    Rig x;DiagCatalog cat;auto c1=ctx();auto c2=ctx();
    core::TaskIdentity t{core::ProjectId::generate(),core::BranchId::generate(),core::RevisionId::generate(),core::RunId::generate(),core::AttemptId::fromCanonical("att-1")};
    c1.task=t;t.attempt=core::AttemptId::fromCanonical("att-2");c2.task=t;
    auto root=x.factory.create(rec(),c1);
    auto ra=rec("RT-RESOURCE-MISSING");ra.level=x.reg.find(ra.code)->level;
    auto rb=rec("RT-RESOURCE-MISSING");rb.level=x.reg.find(rb.code)->level;
    auto a=x.factory.create(ra,c1);auto b=x.factory.create(rb,c2);
    a.causedBy=root.entryId;b.causedBy=root.entryId;
    ASSERT_NO_THROW({cat.append(root);cat.append(a);cat.append(b);});
    std::cout<<"acceptedCatalogSize="<<cat.size()<<" canonical memberLevels="<<int(a.record.level)<<","<<int(b.record.level)<<'\n';
    DiagnosticAggregator ag;for(auto&g:ag.aggregate({root,a,b},{})){
        std::cout<<"group count="<<g.members.size()<<'\n';EXPECT_EQ(g.members.size(),1u);
    }
}

